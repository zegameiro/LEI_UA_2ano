# BD: Guião 4

## ​Problema 4.1

### 1. Sistema de Gestão de um Rent-a-Car

[SQL DDL File](ex_4_1_1.sql "SQLFileQuestion")

![ex_4_1_1 diagram](ex_4_1_1.svg "AnImage")

### 2. Sistema de Gestão de Reservas de Voos

[SQL DDL File](ex_4_1_2.sql "SQLFileQuestion")

![ex_4_1_2 diagram](ex_4_1_2.svg "AnImage")

### 3. Sistema de Gestão de Stocks – Módulo de Encomendas

[SQL DDL File](ex_4_1_3.sql "SQLFileQuestion")

![ex_4_1_3 diagram](ex_4_1_3.svg "AnImage")

### 4. Sistema de Prescrição Eletrónica de Medicamentos 

[SQL DDL File](ex_4_1_4.sql "SQLFileQuestion")

![ex_4_1_4 diagram](ex_4_1_4.svg "AnImage")

### 5. Sistema de Gestão de Conferências

[SQL DDL File](ex_4_1_5.sql "SQLFileQuestion")

![ex_4_1_5 diagram](ex_4_1_5.svg "AnImage")

### 6. Sistema de Gestão de ATL

[SQL DDL File](ex_4_1_6.sql "SQLFileQuestion")

![ex_4_1_6 diagram](ex_4_1_6.svg "AnImage")
